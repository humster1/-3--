﻿using System;


namespace Задание_3_Вар_1
{
    public partial class AddEditForm : Form
    {
        public Food Food { get; set; }

        public AddEditForm(Food? food = null)
        {
            InitializeComponent();

            if (food != null)
            {
                textBox1.Text = food.Name;
                textBox2.Text = food.Protein.ToString();
                textBox3.Text = food.Carbohydrates.ToString();

                if (food is HealthyFood healthyFood)
                {
                    textBox4.Text = healthyFood.Calories.ToString();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                //создаем новый продукт или обновляем существующий
                if (Food == null)
                {
                    Food = new Food(textBox1.Text, int.Parse(textBox2.Text), int.Parse(textBox3.Text));

                    if (!string.IsNullOrEmpty(textBox4.Text))
                    {
                        Food = new HealthyFood(textBox1.Text, int.Parse(textBox2.Text), int.Parse(textBox3.Text), int.Parse(textBox4.Text));
                    }
                }
                else
                {
                    Food.Name = textBox1.Text;
                    Food.Protein = int.Parse(textBox2.Text);
                    Food.Carbohydrates = int.Parse(textBox3.Text);

                    if (Food is HealthyFood healthyFood)
                    {
                        healthyFood.Calories = int.Parse(textBox4.Text);
                    }
                }

                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}

