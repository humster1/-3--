using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace Задание_3_Вар_1
{
    public partial class Form1 : Form
    {
        private BindingList<Food> Foods = new BindingList<Food>()
        {
            new Food("Хлеб", 10, 50),
            new HealthyFood("Яблоко", 0, 20, 30)
        };

        public Form1()
        {
            InitializeComponent();

            dataGridView1.DataSource = Foods;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var addForm = new AddEditForm();
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                //добавляем новый продукт в список
                Foods.Add(addForm.Food);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var selectedFood = dataGridView1.SelectedRows.Cast<DataGridViewRow>().Select(row => row.DataBoundItem as Food).FirstOrDefault();

            if (selectedFood != null)
            {
                //открываем форму для редактирования продукта
                var editForm = new AddEditForm(selectedFood);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    //обновляем данные
                    dataGridView1.Refresh();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var selectedFood = dataGridView1.SelectedRows.Cast<DataGridViewRow>().Select(row => row.DataBoundItem as Food).FirstOrDefault();

            if (selectedFood != null)
            {
                //открываем форму для редактирования продукта
                var editForm = new AddEditForm(selectedFood);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    //обновляем данные
                    dataGridView1.Refresh();
                }
            }
        }
    }
}