﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_3_Вар_1
{
    public class HealthyFood : Food
    {
        public int Calories { get; set; }

        public HealthyFood(string name, int protein, int carbohydrates, int calories) : base(name, protein, carbohydrates)
        {
            Calories = calories;
        }

        public int Qp()
        {
            return base.Q() * 12 / 10 + Calories * 7;
        }

        public override string ToString()
        {
            return $"{base.ToString()}, калорийность: {Calories}ккал, Qp: {Qp()}";
        }
    }
}
