﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_3_Вар_1
{
    public class Food
    {
        public string Name { get; set; }
        public int Protein { get; set; }
        public int Carbohydrates { get; set; }

        public Food(string name, int protein, int carbohydrates)
        {
            Name = name;
            Protein = protein;
            Carbohydrates = carbohydrates;
        }

        public int Q()
        {
            return Carbohydrates * 4 + Protein * 4;
        }

        public override string ToString()
        {
            return $"{Name}, белки: {Protein}г, углеводы: {Carbohydrates}г, Q: {Q()}";
        }
    }
}
